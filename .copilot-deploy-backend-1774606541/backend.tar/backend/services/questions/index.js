const express = require('express');
const multer = require('multer');
const XLSX = require('xlsx');

const router = express.Router();
const upload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: 5 * 1024 * 1024,
    fieldSize: 10 * 1024 * 1024,
  },
});

const getUserRoleNames = (user) => {
  if (!user || !Array.isArray(user.roles)) return [];
  return user.roles
    .map((role) => String(role?.name || role?.role || '').toLowerCase())
    .filter(Boolean);
};

const requireAdmin = (req, res, next) => {
  if (!req.user || !req.user.id) return res.status(401).json({ error: 'Access token required' });
  const roleNames = getUserRoleNames(req.user);
  const isAdmin =
    roleNames.includes('admin') ||
    String(req.user.role || '').toLowerCase() === 'admin' ||
    String(req.user.email || '').toLowerCase() === String(process.env.ADMIN_EMAIL || 'admin@skdcpns.com').toLowerCase();
  if (!isAdmin) return res.status(403).json({ error: 'Forbidden - admin only' });
  return next();
};

const normalizeKey = (value) => String(value || '')
  .trim()
  .toLowerCase()
  .replace(/\uFEFF/g, '')
  .replace(/[^a-z0-9]+/g, '_')
  .replace(/^_+|_+$/g, '');

const normalizeRow = (row) => {
  const normalized = {};
  for (const [key, value] of Object.entries(row || {})) {
    normalized[normalizeKey(key)] = value;
  }
  return normalized;
};

const pickValue = (row, aliases = []) => {
  for (const alias of aliases) {
    const value = row[normalizeKey(alias)];
    if (value !== undefined && value !== null && String(value).trim() !== '') return value;
  }
  return null;
};

const toNumberOrNull = (value) => {
  if (value === null || value === undefined || String(value).trim() === '') return null;
  const parsed = Number(String(value).replace(',', '.'));
  return Number.isFinite(parsed) ? parsed : null;
};

const toIntegerOrNull = (value) => {
  if (value === null || value === undefined || String(value).trim() === '') return null;
  const parsed = Number(value);
  return Number.isInteger(parsed) ? parsed : null;
};

const aliasMap = {
  number: ['number', 'no', 'nomor'],
  question_text: ['question_text', 'question', 'soal', 'pertanyaan'],
  option_a: ['option_a', 'a', 'pilihan_a'],
  option_b: ['option_b', 'b', 'pilihan_b'],
  option_c: ['option_c', 'c', 'pilihan_c'],
  option_d: ['option_d', 'd', 'pilihan_d'],
  option_e: ['option_e', 'e', 'pilihan_e'],
  correct_answer: ['correct_answer', 'answer', 'jawaban_benar', 'kunci_jawaban'],
  explanation: ['explanation', 'pembahasan', 'penjelasan'],
  category: ['category', 'kategori'],
  point_a: ['point_a', 'poin_a', 'nilai_a'],
  point_b: ['point_b', 'poin_b', 'nilai_b'],
  point_c: ['point_c', 'poin_c', 'nilai_c'],
  point_d: ['point_d', 'poin_d', 'nilai_d'],
  point_e: ['point_e', 'poin_e', 'nilai_e'],
  poin_benar: ['poin_benar', 'point_correct', 'nilai_benar', 'correct_point', 'poin_jawaban_benar'],
  image_url: ['image_url', 'gambar', 'url_gambar', 'image'],
};

const defaultColumnIndexMap = {
  number: 0,
  question_text: 1,
  option_a: 2,
  option_b: 3,
  option_c: 4,
  option_d: 5,
  option_e: 6,
  correct_answer: 7,
  explanation: 8,
  category: 9,
  point_a: 10,
  point_b: 11,
  point_c: 12,
  point_d: 13,
  point_e: 14,
  poin_benar: 15,
  image_url: 16,
};

// For TWK/TIU: if poin_benar is set, auto-fill point columns
// (correct option = poin_benar, wrong options = 0), unless already explicitly set
const applyPoinBenar = (points, poinBenar, correctAnswer) => {
  if (poinBenar === null || !correctAnswer) return points;
  const ca = String(correctAnswer).trim().toUpperCase();
  const result = { ...points };
  ['a', 'b', 'c', 'd', 'e'].forEach((opt) => {
    const key = `point_${opt}`;
    if (result[key] === null) {
      result[key] = ca === opt.toUpperCase() ? poinBenar : 0;
    }
  });
  return result;
};

const detectHeaderIndexMap = (grid) => {
  for (let rowIdx = 0; rowIdx < Math.min(15, grid.length); rowIdx += 1) {
    const row = grid[rowIdx] || [];
    const normalizedCells = row.map((cell) => normalizeKey(cell));
    const map = {};

    Object.entries(aliasMap).forEach(([key, aliases]) => {
      const aliasSet = new Set(aliases.map((item) => normalizeKey(item)));
      const foundIndex = normalizedCells.findIndex((cell) => aliasSet.has(cell));
      if (foundIndex >= 0) map[key] = foundIndex;
    });

    if (typeof map.number === 'number' && typeof map.question_text === 'number') {
      return { headerRowIndex: rowIdx, indexMap: map };
    }
  }

  return { headerRowIndex: -1, indexMap: defaultColumnIndexMap };
};

const isLikelyNumberCell = (value) => {
  if (value === null || value === undefined) return false;
  const text = String(value).trim();
  if (!text) return false;
  return Number.isFinite(Number(text.replace(',', '.')));
};

const detectDataStartOffset = (grid, startRow = 0) => {
  const score = new Map();

  for (let r = startRow; r < Math.min(grid.length, startRow + 200); r += 1) {
    const row = grid[r] || [];
    if (!row.length) continue;

    for (let i = 0; i < Math.min(10, row.length); i += 1) {
      const maybeNumber = row[i];
      const maybeQuestionAtPlus1 = row[i + 1];
      const maybeQuestionAtPlus2 = row[i + 2];

      const looksValid1 = isLikelyNumberCell(maybeNumber) && maybeQuestionAtPlus1 && String(maybeQuestionAtPlus1).trim().length >= 5;
      const looksValid2 = isLikelyNumberCell(maybeNumber) && maybeQuestionAtPlus2 && String(maybeQuestionAtPlus2).trim().length >= 5;

      if (looksValid1 || looksValid2) {
        score.set(i, (score.get(i) || 0) + 1);
      }
    }
  }

  if (!score.size) return 0;

  let bestOffset = 0;
  let bestScore = -1;
  for (const [offset, value] of score.entries()) {
    if (value > bestScore) {
      bestScore = value;
      bestOffset = offset;
    }
  }

  return bestOffset;
};

const buildRowsFromWorksheetFallback = (worksheet) => {
  const grid = XLSX.utils.sheet_to_json(worksheet, { header: 1, defval: null, raw: false });
  if (!grid.length) return [];

  const { headerRowIndex, indexMap } = detectHeaderIndexMap(grid);
  const startDataIndex = headerRowIndex >= 0 ? headerRowIndex + 1 : 0;
  const offset = headerRowIndex >= 0 ? 0 : detectDataStartOffset(grid, startDataIndex);

  const effectiveIndexMap = {};
  Object.entries(indexMap).forEach(([key, idx]) => {
    effectiveIndexMap[key] = idx + offset;
  });

  const rows = [];
  for (let i = startDataIndex; i < grid.length; i += 1) {
    const row = grid[i] || [];
    const normalized = {};
    Object.entries(effectiveIndexMap).forEach(([key, idx]) => {
      normalized[key] = row[idx] ?? null;
    });
    rows.push(normalized);
  }
  return rows;
};

router.get('/questions/package/:packageId', async (req, res) => {
  try {
    const db = req.app.locals.db;
    const packageId = Number(req.params.packageId);
    if (!Number.isInteger(packageId)) return res.status(400).json({ error: 'Invalid package id' });

    const result = await db.query(
      'SELECT * FROM questions WHERE package_id = $1 ORDER BY number ASC, id ASC',
      [packageId]
    );

    return res.json(result.rows || []);
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
});

router.get('/questions/:id', async (req, res) => {
  try {
    const db = req.app.locals.db;
    const questionId = Number(req.params.id);
    if (!Number.isInteger(questionId)) return res.status(400).json({ error: 'Invalid question id' });

    const result = await db.query('SELECT * FROM questions WHERE id = $1 LIMIT 1', [questionId]);
    const question = result.rows[0];
    if (!question) return res.status(404).json({ error: 'Question not found' });
    return res.json(question);
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
});

router.post('/questions/upload', requireAdmin, upload.single('file'), async (req, res) => {
  const db = req.app.locals.db;
  const packageId = Number(req.body?.packageId);

  if (!Number.isInteger(packageId)) {
    return res.status(400).json({ error: 'Invalid package id' });
  }

  if (!req.file) {
    return res.status(400).json({ error: 'File is required' });
  }

  try {
    const workbook = XLSX.read(req.file.buffer, { type: 'buffer' });
    const firstSheetName = workbook.SheetNames?.[0];
    if (!firstSheetName) {
      return res.status(400).json({ error: 'Excel file is empty' });
    }

    const worksheet = workbook.Sheets[firstSheetName];
    const rows = XLSX.utils.sheet_to_json(worksheet, { defval: null });

    if (!rows.length) {
      return res.status(400).json({ error: 'No rows found in Excel' });
    }

    await db.query('BEGIN');

    let insertedCount = 0;
    for (const sourceRow of rows) {
      const row = normalizeRow(sourceRow);

      const number = toNumberOrNull(pickValue(row, ['number', 'no', 'nomor']));
      const questionTextRaw = pickValue(row, ['question_text', 'question', 'soal', 'pertanyaan']);
      const questionText = questionTextRaw ? String(questionTextRaw).trim() : '';

      if (!Number.isInteger(number) || !questionText) {
        continue;
      }

      const optionA = pickValue(row, ['option_a', 'a', 'pilihan_a']);
      const optionB = pickValue(row, ['option_b', 'b', 'pilihan_b']);
      const optionC = pickValue(row, ['option_c', 'c', 'pilihan_c']);
      const optionD = pickValue(row, ['option_d', 'd', 'pilihan_d']);
      const optionE = pickValue(row, ['option_e', 'e', 'pilihan_e']);
      const correctAnswer = pickValue(row, ['correct_answer', 'answer', 'jawaban_benar', 'kunci_jawaban']);
      const explanation = pickValue(row, ['explanation', 'pembahasan', 'penjelasan']);
      const category = pickValue(row, ['category', 'kategori']);
      const imageUrl = pickValue(row, ['image_url', 'gambar', 'url_gambar', 'image']);
      const poinBenar = toNumberOrNull(pickValue(row, ['poin_benar', 'point_correct', 'nilai_benar', 'correct_point', 'poin_jawaban_benar']));

      const caStr = correctAnswer ? String(correctAnswer).trim().toUpperCase() : null;
      const points = applyPoinBenar(
        {
          point_a: toNumberOrNull(pickValue(row, ['point_a', 'poin_a', 'nilai_a'])),
          point_b: toNumberOrNull(pickValue(row, ['point_b', 'poin_b', 'nilai_b'])),
          point_c: toNumberOrNull(pickValue(row, ['point_c', 'poin_c', 'nilai_c'])),
          point_d: toNumberOrNull(pickValue(row, ['point_d', 'poin_d', 'nilai_d'])),
          point_e: toNumberOrNull(pickValue(row, ['point_e', 'poin_e', 'nilai_e'])),
        },
        poinBenar,
        caStr
      );

      await db.query(
        `INSERT INTO questions (
          package_id, number, question_text,
          option_a, option_b, option_c, option_d, option_e,
          correct_answer, explanation, category,
          point_a, point_b, point_c, point_d, point_e,
          image_url, created_at, updated_at
        ) VALUES (
          $1, $2, $3,
          $4, $5, $6, $7, $8,
          $9, $10, $11,
          $12, $13, $14, $15, $16,
          $17, NOW(), NOW()
        )`,
        [
          packageId,
          number,
          questionText,
          optionA ? String(optionA) : null,
          optionB ? String(optionB) : null,
          optionC ? String(optionC) : null,
          optionD ? String(optionD) : null,
          optionE ? String(optionE) : null,
          caStr,
          explanation ? String(explanation) : null,
          category ? String(category).trim().toUpperCase() : null,
          points.point_a,
          points.point_b,
          points.point_c,
          points.point_d,
          points.point_e,
          imageUrl ? String(imageUrl) : null,
        ]
      );

      insertedCount += 1;
    }

    if (insertedCount === 0) {
      const fallbackRows = buildRowsFromWorksheetFallback(worksheet);

      for (const row of fallbackRows) {
        const number = toNumberOrNull(pickValue(row, aliasMap.number));
        const questionTextRaw = pickValue(row, aliasMap.question_text);
        const questionText = questionTextRaw ? String(questionTextRaw).trim() : '';

        if (!Number.isInteger(number) || !questionText) {
          continue;
        }

        const optionA = pickValue(row, aliasMap.option_a);
        const optionB = pickValue(row, aliasMap.option_b);
        const optionC = pickValue(row, aliasMap.option_c);
        const optionD = pickValue(row, aliasMap.option_d);
        const optionE = pickValue(row, aliasMap.option_e);
        const correctAnswer = pickValue(row, aliasMap.correct_answer);
        const explanation = pickValue(row, aliasMap.explanation);
        const category = pickValue(row, aliasMap.category);
        const imageUrl = pickValue(row, aliasMap.image_url);
        const poinBenar = toNumberOrNull(pickValue(row, aliasMap.poin_benar));

        const caStr = correctAnswer ? String(correctAnswer).trim().toUpperCase() : null;
        const points = applyPoinBenar(
          {
            point_a: toNumberOrNull(pickValue(row, aliasMap.point_a)),
            point_b: toNumberOrNull(pickValue(row, aliasMap.point_b)),
            point_c: toNumberOrNull(pickValue(row, aliasMap.point_c)),
            point_d: toNumberOrNull(pickValue(row, aliasMap.point_d)),
            point_e: toNumberOrNull(pickValue(row, aliasMap.point_e)),
          },
          poinBenar,
          caStr
        );

        await db.query(
          `INSERT INTO questions (
            package_id, number, question_text,
            option_a, option_b, option_c, option_d, option_e,
            correct_answer, explanation, category,
            point_a, point_b, point_c, point_d, point_e,
            image_url, created_at, updated_at
          ) VALUES (
            $1, $2, $3,
            $4, $5, $6, $7, $8,
            $9, $10, $11,
            $12, $13, $14, $15, $16,
            $17, NOW(), NOW()
          )`,
          [
            packageId,
            number,
            questionText,
            optionA ? String(optionA) : null,
            optionB ? String(optionB) : null,
            optionC ? String(optionC) : null,
            optionD ? String(optionD) : null,
            optionE ? String(optionE) : null,
            caStr,
            explanation ? String(explanation) : null,
            category ? String(category).trim().toUpperCase() : null,
            points.point_a,
            points.point_b,
            points.point_c,
            points.point_d,
            points.point_e,
            imageUrl ? String(imageUrl) : null,
          ]
        );

        insertedCount += 1;
      }
    }

    if (insertedCount === 0) {
      await db.query('ROLLBACK');
      const preview = rows.slice(0, 2).map((item) => Object.keys(item || {}));
      return res.status(400).json({
        error: 'No valid rows to import. Pastikan kolom nomor dan teks soal terisi.',
        hint: 'Gunakan header: number, question_text, option_a..option_e, correct_answer, explanation, category, poin_benar (TWK/TIU), point_a..point_e (TKP), image_url',
        previewHeaders: preview,
      });
    }

    await db.query('COMMIT');

    await db.query(
      'UPDATE packages SET question_count = (SELECT COUNT(*) FROM questions WHERE package_id = $1), updated_at = NOW() WHERE id = $1',
      [packageId]
    ).catch(() => {});

    return res.json({
      message: `${insertedCount} questions imported successfully`,
      count: insertedCount,
    });
  } catch (error) {
    try { await db.query('ROLLBACK'); } catch (_) {}
    return res.status(500).json({ error: error.message });
  }
});

router.post('/questions/:id/image', requireAdmin, upload.single('image'), async (req, res) => {
  try {
    const db = req.app.locals.db;
    const questionId = Number(req.params.id);
    if (!Number.isInteger(questionId)) return res.status(400).json({ error: 'Invalid question id' });

    let finalImageUrl = req.body?.imageUrl || null;

    if (req.file) {
      const mimeType = req.file.mimetype || 'image/jpeg';
      const allowed = ['image/png', 'image/jpeg', 'image/jpg', 'image/webp', 'image/gif'];
      if (!allowed.includes(mimeType)) {
        return res.status(400).json({ error: 'Invalid image type' });
      }
      finalImageUrl = `data:${mimeType};base64,${req.file.buffer.toString('base64')}`;
    }

    if (!finalImageUrl) {
      return res.status(400).json({ error: 'Image URL or file is required' });
    }

    const result = await db.query(
      'UPDATE questions SET image_url = $1, updated_at = NOW() WHERE id = $2 RETURNING *',
      [finalImageUrl, questionId]
    );

    if (!result.rows[0]) return res.status(404).json({ error: 'Question not found' });

    return res.json({
      message: 'Image updated successfully',
      image_url: finalImageUrl,
      question: result.rows[0],
    });
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
});

router.put('/questions/:id', requireAdmin, async (req, res) => {
  try {
    const db = req.app.locals.db;
    const questionId = Number(req.params.id);
    if (!Number.isInteger(questionId)) return res.status(400).json({ error: 'Invalid question id' });

    const body = req.body || {};
    const payload = {
      number: toIntegerOrNull(body.number),
      question_text: body.question_text !== undefined ? String(body.question_text || '') : null,
      option_a: body.option_a !== undefined ? String(body.option_a || '') : null,
      option_b: body.option_b !== undefined ? String(body.option_b || '') : null,
      option_c: body.option_c !== undefined ? String(body.option_c || '') : null,
      option_d: body.option_d !== undefined ? String(body.option_d || '') : null,
      option_e: body.option_e !== undefined ? String(body.option_e || '') : null,
      correct_answer: body.correct_answer !== undefined ? String(body.correct_answer || '').trim().toUpperCase() : null,
      explanation: body.explanation !== undefined ? String(body.explanation || '') : null,
      category: body.category !== undefined ? String(body.category || '').trim().toUpperCase() : null,
      point_a: body.point_a !== undefined ? toNumberOrNull(body.point_a) : null,
      point_b: body.point_b !== undefined ? toNumberOrNull(body.point_b) : null,
      point_c: body.point_c !== undefined ? toNumberOrNull(body.point_c) : null,
      point_d: body.point_d !== undefined ? toNumberOrNull(body.point_d) : null,
      point_e: body.point_e !== undefined ? toNumberOrNull(body.point_e) : null,
      image_url: body.image_url !== undefined ? (body.image_url ? String(body.image_url) : null) : null,
    };

    Object.keys(payload).forEach((key) => {
      if (payload[key] === null && body[key] === undefined) delete payload[key];
    });

    if (!Object.keys(payload).length) {
      return res.status(400).json({ error: 'No valid fields to update' });
    }

    const fields = Object.keys(payload);
    const setClauses = fields.map((field, idx) => `${field} = $${idx + 1}`);
    const values = fields.map((field) => payload[field]);

    values.push(questionId);
    const query = `
      UPDATE questions
      SET ${setClauses.join(', ')}, updated_at = NOW()
      WHERE id = $${values.length}
      RETURNING *
    `;

    const result = await db.query(query, values);
    if (!result.rows[0]) return res.status(404).json({ error: 'Question not found' });

    return res.json({ message: 'Question updated successfully', question: result.rows[0] });
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
});

module.exports = router;
